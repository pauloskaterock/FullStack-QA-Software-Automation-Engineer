
def diga_ola(nome)
    puts 'Olá, ' + nome
end

diga_ola('Fernando')

# def soma(v1, v2)
#     total = v1 + v2
#     total
# end

# res = soma(10,25)
# puts res