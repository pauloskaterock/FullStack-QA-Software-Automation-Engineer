puts 'Olá Ruby!'
